<?php
    $connection = pg_connect("host=localhost user=carloslr password=123 dbname=peliculas");
?>